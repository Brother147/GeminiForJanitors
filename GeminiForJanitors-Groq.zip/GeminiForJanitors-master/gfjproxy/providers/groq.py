from typing import Any

import httpx2

from .._globals import PROCESS_TIMEOUT
from ..http_client import http_client
from ..logging import xlog
from ..models import JaiMessage, JaiResult, JaiResultMetadata, JaiResultTokenUsage
from ..statistics import track_stats
from ..xuiduser import XUID


GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"


def groq_generate_content(
    user: XUID,
    api_key: str,
    model: str,
    messages: list[JaiMessage],
    settings: dict[str, Any] | None = None,
) -> JaiResult:
    """Wrapper around Groq's OpenAI-compatible Chat Completions API."""

    groq_request: dict[str, Any] = {
        "model": model,
        "stream": False,
        "messages": [
            {
                "content": message.content,
                "role": message.role,
            }
            for message in messages
        ],
    }

    for key, value in (settings or {}).items():
        if key == "temperature":
            groq_request["temperature"] = value
        elif key == "max_tokens":
            # Groq accepts max_tokens as a deprecated alias, but its current
            # preferred field is max_completion_tokens.
            groq_request["max_completion_tokens"] = value
        elif key == "top_p":
            groq_request["top_p"] = value
        elif key == "frequency_penalty":
            groq_request["frequency_penalty"] = value
        elif key == "repetition_penalty":
            # Groq's Chat API does not expose repetition_penalty. Keep the
            # same semantic mapping used by the other OpenAI-compatible
            # providers in this proxy.
            groq_request["presence_penalty"] = value

    headers = {
        "Authorization": f"Bearer {api_key.removeprefix('groq/')}",
        "Content-Type": "application/json",
    }

    try:
        groq_response = http_client.post(
            GROQ_API_URL,
            json=groq_request,
            headers=headers,
            timeout=PROCESS_TIMEOUT,
        )
        groq_response.raise_for_status()
        groq_result = groq_response.json()
    except httpx2.TimeoutException:
        track_stats("groq.time_out")
        return JaiResult(504, "Gateway Timeout")
    except httpx2.HTTPStatusError as e:
        message = "Error from Groq"
        extras = ""

        try:
            error = e.response.json()
        except Exception:  # noqa: BLE001
            error = None

        if isinstance(error, dict):
            if isinstance(error.get("error"), dict):
                error = error["error"]

            if isinstance(error, dict):
                if error_code := error.get("code"):
                    message += f" ({error_code})"
                if error_message := error.get("message"):
                    message += f": {error_message}"
        else:
            xlog(user, f"{message}: {e.response.text!r}")

        if e.response.is_client_error:
            track_stats("groq.failed.client")
        elif e.response.is_server_error:
            track_stats("groq.failed.server")
        else:
            track_stats("groq.failed.unknown")

        return JaiResult(e.response.status_code, message, extras=extras)
    except Exception as e:  # ruff: ignore[BLE001]
        xlog(user, repr(e))
        track_stats("groq.failed.exception")
        return JaiResult(502, "Unhandled exception from Groq.")

    if isinstance(error := groq_result.get("error"), dict) and error:
        message = "Error from Groq"
        if error_code := error.get("code"):
            message += f" ({error_code})"
        if error_message := error.get("message"):
            message += f": {error_message}"
        xlog(user, f"Error despite successful status: {groq_result!r}")
        track_stats("groq.failed.anomalous")
        return JaiResult(502, message)

    try:
        text = str(groq_result["choices"][0]["message"]["content"] or "")
    except (KeyError, IndexError, TypeError):
        text = ""

    metadata = JaiResultMetadata()
    if usage := groq_result.get("usage"):
        metadata.token_usage = JaiResultTokenUsage(
            prompt_tokens=usage.get("prompt_tokens"),
            completion_tokens=usage.get("completion_tokens"),
            reasoning_tokens=usage.get("completion_tokens_details", {}).get(
                "reasoning_tokens"
            ),
            total_tokens=usage.get("total_tokens"),
        )

    if not text:
        xlog(user, f"No result text: {groq_result!r}")
        track_stats("groq.rejected")
        return JaiResult(502, "Response blocked/empty.", metadata=metadata)

    track_stats("groq.succeeded")
    return JaiResult(200, text, metadata=metadata)
