from unittest.mock import Mock, patch

from gfjproxy.models import JaiMessage
from gfjproxy.providers.groq import groq_generate_content
from gfjproxy.xuiduser import XUID


def test_groq_request_and_response():
    response = Mock()
    response.status_code = 200
    response.json.return_value = {
        "choices": [{"message": {"content": "Hello from Groq"}}],
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 4,
            "total_tokens": 14,
        },
    }
    response.raise_for_status.return_value = None

    with patch(
        "gfjproxy.providers.groq.http_client.post",
        return_value=response,
    ) as post:
        result = groq_generate_content(
            XUID("test", "user"),
            "groq/gsk_test",
            "openai/gpt-oss-120b",
            [JaiMessage(role="user", content="Hello")],
            {
                "temperature": 0.7,
                "max_tokens": 2048,
                "top_p": 0.9,
            },
        )

    assert result.status == 200
    assert result.text == "Hello from Groq"
    assert result.metadata.token_usage is not None
    assert result.metadata.token_usage.total_tokens == 14

    _, kwargs = post.call_args
    assert kwargs["headers"]["Authorization"] == "Bearer gsk_test"
    assert kwargs["json"]["model"] == "openai/gpt-oss-120b"
    assert kwargs["json"]["max_completion_tokens"] == 2048
    assert kwargs["json"]["temperature"] == 0.7
    assert kwargs["json"]["top_p"] == 0.9
